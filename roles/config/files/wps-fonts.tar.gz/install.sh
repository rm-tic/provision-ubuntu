#!/bin/bash

cd "$( dirname "${BASH_SOURCE[0]}" )"

if [[ $(id -u) -ne 0 ]] ; then
  echo "This script requires sudo privileges"
  exit 1
fi

FONT_PATH="/usr/share/fonts/wps-fonts"

if [ ! -d "$FONT_PATH" ]; then
  echo "Creating Font Directory..."
  mkdir $FONT_PATH
fi

echo "Installing Fonts..."
cp *.ttf $FONT_PATH
cp *.TTF $FONT_PATH
echo "Fixing Permissions..."
chmod 644 $FONT_PATH/*
echo "Rebuilding Font Cache..."
fc-cache -vfs
echo "Installation Finished."

exit 0
